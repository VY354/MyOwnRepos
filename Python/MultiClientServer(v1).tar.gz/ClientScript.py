import os
import socket
import _thread
import re

from dataclasses import dataclass, asdict, astuple, fields, field

from termcolor import colored


@dataclass(init=True, repr=True)
class MyClient:
    clientSocket: socket.socket = field(init=False, default=None)

    def create(self):
        self.clientSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    def connectTo(self, addr: tuple):
        try:
            self.clientSocket.connect(addr)
        except socket.error as e:
            return

    def close(self):
        self.clientSocket.close()

    def sendMessage(self, message: str):
        self.clientSocket.send(message.encode('utf-8'))

    def echo(self, string: str):
        print(string)

    def recv(self, size=1024):
        return self.clientSocket.recv(size)


@dataclass(init=True, repr=True)
class ClientManager:
    numOfClients: int = field(init=False, default=0)
    clientsList: list = field(init=False, default_factory=list)

    def start(self):
        ans = None
        currClient: MyClient
        currClient = None

        while True:

            self.menu()
            print('=========================================================')
            if currClient:
                print(f'Current client ---> {self.paintAddr(currClient.clientSocket.getsockname())}')
                print('=========================================================')
            ans = int(input('select action: '))

            os.system('clear')

            if ans == 1:
                if currClient:
                    mes = input('CLIENT MANAGER >>> write message: ')
                    currClient.sendMessage(mes)
                    reply = currClient.recv(1024)
                    os.system('clear')
                    print(f'CLIENT MANAGER >>> {colored("server reply", "cyan")}  ::::: {reply.decode("utf-8")}')
            elif ans == 3:
                if len(self.clientsList):
                    currClient = self.selectClient()
            elif ans == 5:
                os.system('clear')
                self.addClient()
            elif ans == 7:
                if currClient:
                    mes = f'CLIENT MANAGER >>> {colored("client disconnected", "red")}: {self.paintAddr(currClient.clientSocket.getsockname())}'
                    currClient.close()
                    self.clientsList.remove(currClient)
                    os.system('clear')
                    currClient = None
                    self.echo(mes)
            elif ans == 0:
                for cli in self.clientsList:
                    cli.close()
                break

    def selectClient(self):
        ans = -1
        while ans < 0 or ans >= len(self.clientsList):
            os.system('clear')
            cli: MyClient
            for n, cli in enumerate(self.clientsList):
                print(f'{n:>3} --- {self.paintAddr(cli.clientSocket.getsockname())}')
            print('=======================================')
            ans = int(input('Select client: '))
        os.system('clear')
        return self.clientsList[ans]

    def addClient(self):
        newClient = MyClient()
        newClient.create()
        newClient.connectTo((serverIP, serverPORT))
        try:
            newClient.connectTo((serverIP, serverPORT))
        except socket.error as e:
            self.echo(f'{colored(f"{e}", "red")}')
            return 0
        self.clientsList.append(newClient)
        print(
            f'CLIENT MANAGER >>> Client {self.paintAddr(newClient.clientSocket.getsockname())} {colored("connected to server", "green")}')

    def paintAddr(self, addr):
        return colored(f'{addr[0]}', "yellow") + ':' + colored(f'{addr[1]}', "yellow")

    def echo(self, string: str):
        print(string)

    def menu(self):
        print('=========================================================')
        print('1 --- continue')
        print('------------------------------------')
        print('3 --- select another client')
        print('5 --- add new client')
        print('7 --- disconnect')
        print('------------------------------------')
        print('0 --- exit')


serverIP = '127.0.0.1'
serverPORT = 7777


def main():
    cliManager = ClientManager()
    cliManager.start()


if __name__ == '__main__':
    main()
