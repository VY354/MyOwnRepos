import os
from dataclasses import dataclass, asdict, astuple, fields, field
from abc import ABC, abstractmethod
import csv


DBFilesDirName = 'DBFiles'

def saveDBtoCSV(DBName : dict):
    fileName = list(DBName.keys())[0]
    if not os.path.exists(f'{DBFilesDirName}/{fileName}.csv'):
        os.system(f'touch {DBFilesDirName}/{fileName}.csv')
    with open(f'{DBFilesDirName}/{fileName}.csv','w') as out:
        csvWriter = csv.writer(out)
        csvWriter.writerow(DBName.keys())
        csvWriter.writerows(zip(*DBName.values()))



def loadDBfromCSV(DBName : str):
    pass


def main():
    # dirs = os.listdir(DBFilesDirName)
    # files = [x for x in dirs if os.path.isfile(f'{DBFilesDirName}/{x}')]

    data = {}
    keys=list('ab')
    vals = [[y for y in range(10,100,10)] for x in range(len(keys))]
    data[keys[0]]=[y for y in range(0,110,10)]
    print(data)
    saveDBtoCSV(data)




if __name__ =='__main__':
    main()


