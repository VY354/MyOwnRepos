from math import *
import random

import dataclasses
from dataclasses import dataclass, field, fields, asdict, astuple

import numpy as np

from particle import *


@dataclass
class PSO:
    funcToEval: object = field(default=None, init=False)
    action: bool = field(default=True, init=False)
    resultPos: np.array = field(default=None, init=False)
    resultValue: float = field(default=None,init=False)

    maxIterations: int = field(default=100)

    particleQuantity: int = field(default=20)
    particles: list = field(default=None, init=False)

    communicationDistance: float = field(default=1)
    inertia: float = field(default=1)
    C1: float = field(default=1)
    C2: float = field(default=1)

    def Initialize(self):
        self.particles = [Particle() for i in range(self.particleQuantity)]
        p: Particle
        for p in self.particles:
            p.position = np.random.uniform(-pi, pi, 2)
            p.velocity = np.random.uniform(-1, 1, 2)
            p.personalBest = self.funcToEval(*p.position)
            p.pbPosition=p.position

    def Run(self):
        for i in range(self.maxIterations):
            self._Iterate()

    def _Iterate(self):
        p: Particle
        groupBestPos = self._GetGroupBest()
        for p in self.particles:
            p.velocity = self.inertia * p.velocity + self.C1 * random.random() * (
                    p.pbPosition - p.position) + self.C2 * random.random() * (groupBestPos - p.position)
            p.position = p.position + p.velocity
            self.UpdatePB(p)

        self.resultPos,self.resultValue = self._GetBestResultPos()


    def _GetGroupBest(self) -> np.array:
        bestPos=self.particles[0].position
        fbest = self.funcToEval(*bestPos)
        for p in self.particles[1:]:
            if self.action:
                if (p.personalBest > fbest):
                    bestPos = p.personalBest
                    bestPos= p.pbPosition
            elif not self.action:
                if (p.personalBest < fbest):
                    bestPos = p.personalBest
                    bestPos= p.pbPosition
        return bestPos

    def UpdatePB(self,p:Particle):
        funcVal = self.funcToEval(*p.position)
        if self.action:
            if(funcVal>p.personalBest):
                p.personalBest=funcVal
                p.pbPosition=p.position
        elif not self.action:
            if(funcVal<p.personalBest):
                p.personalBest=funcVal
                p.pbPosition=p.position


    def _GetBestResultPos(self):
        poses = np.array([p.position for p in self.particles])
        avgPos = np.array([0,0],dtype='float64')
        for p in poses:
            avgPos+=p
        avgPos/=self.particleQuantity
        avgRes = np.array([self.funcToEval(*pos) for pos in poses]).mean()
        return avgPos,avgRes

def test():
    pso = PSO()
    pso.action=False

    pso.maxIterations=100
    pso.particleQuantity=50

    pso.inertia=0.5
    pso.C1=1
    pso.C2=3
    pso.communicationDistance=10

    pso.funcToEval = lambda x, y: np.cos(x) * np.sin(y)

    pso.Initialize()
    pso.Run()

    print('=================================================================')
    print(pso.resultPos,pso.resultValue)


if __name__ == '__main__':
    test()
