
import numpy as np

import dataclasses
from dataclasses import dataclass,field,fields, asdict,astuple

@dataclass
class Particle:

    position: np.array = field(default=None,init=False)
    velocity: float = field(default=0,init=False)
    pbPosition: np.array =field(default=None,init=False)
    personalBest: float = field(default=0,init=False)



