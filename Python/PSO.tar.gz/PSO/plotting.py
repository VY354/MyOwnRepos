
from math import *
import numpy as np
import  matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib import cm
import matplotlib.animation as animation

from pso_alg import *


def test():
    pso = PSO()
    pso.action = False
    pso.maxIterations = 50
    pso.particleQuantity = 50

    pso.inertia = 0.5
    pso.C1 = 0.2
    pso.C2 = 1
    pso.communicationDistance = 12

    pso.funcToEval = lambda x, y: np.sin(np.square(x/2)+np.square(y/2))

    pso.Initialize()
    # pso.Run()

    a=-2*pi
    b=2*pi

    x = np.linspace(a,b,50)
    y = np.linspace(a,b,50)
    x,y = np.meshgrid(x,y)

    z = pso.funcToEval(x,y)

    fig = plt.figure(figsize=(12,7))
    ax1 = fig.add_subplot(111,projection='3d')
    ax1.set_zlim(-3,3)
    funcplot = ax1.contour3D(x,y,z, 50,cmap=cm.get_cmap('binary'),alpha=0.25)

    scatParticles = ax1.scatter([0],[0],[0],marker='o',color='lime',s=30*pi,alpha=1,edgecolors='orangered',)
    # scatBestPos = ax1.scatter([0],[0],[0],marker='o',s=50*pi,color='orange',alpha=1)



    def anim(t):

        pso._Iterate()

        sx = [p.position[0] for p in pso.particles]
        sy = [p.position[1] for p in pso.particles]
        sz = [pso.funcToEval(*p.position) for p in pso.particles]

        bestPos = pso.resultPos
        res = pso.resultValue

        scatParticles._offsets3d=(sx,sy,sz)
        # scatBestPos._offsets3d=([bestPos[0]],[bestPos[1]],[res])

        return scatParticles,


    anim1 = animation.FuncAnimation(fig=fig,func=anim,interval=1,blit=False)

    plt.interactive(False)
    plt.tight_layout()
    plt.show()

if __name__ == '__main__':
    test()




