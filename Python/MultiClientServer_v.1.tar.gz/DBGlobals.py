DBs = {}
currDB = {'name_db':None,'db':None}