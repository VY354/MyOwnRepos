import os
from math import *

from dataclasses import dataclass, asdict, astuple, fields, field
from abc import ABC, abstractmethod

from DBGlobals import *


def commandDecorator(execFunc):
    def decorator(*args, **kwargs):
        try:
            execFunc(*args, **kwargs)
        except Exception as e:
            return -1
    return decorator

@dataclass
class commandAbstract(ABC):
    command : str = field(default='')

    @abstractmethod
    def exec(self,*args,**kwargs):
        pass


@dataclass
class setCommand(commandAbstract):
    global currDB
    global DBs

    def __init__(self):
        super(setCommand, self).__init__()
        self.command='set'

    @commandDecorator
    def exec(self,*args, **kwargs):
        for i in range(0,len(args),2):
            currDB['db'][args[i]]=args[i+1]
        return 1


@dataclass
class getCommand(commandAbstract):
    global currDB
    global DBs

    def __init__(self):
        super(getCommand, self).__init__()
        self.command='get'

    @commandDecorator
    def exec(self,*args, **kwargs):
        for key in args:
            print( currDB['db'][key])
        return 1


@dataclass
class createDBCommand(commandAbstract):
    global currDB
    global DBs

    def __init__(self):
        super(createDBCommand, self).__init__()
        self.command='cdb'

    @commandDecorator
    def exec(self,*args, **kwargs):
        DBs[args[0]] = {}
        return 1


@dataclass
class useDBCommand(commandAbstract):
    global currDB
    global DBs

    def __init__(self):
        super(useDBCommand, self).__init__()
        self.command='udb'

    @commandDecorator
    def exec(self,*args, **kwargs):
        if args[0] not in DBs.keys():
            return -1
        currDB['name_db'] = args[0]
        currDB['db'] = DBs[args[0]]
        return 1


@dataclass
class exitCommand(commandAbstract):
    global currDB
    global DBs

    def __init__(self):
        super(exitCommand, self).__init__()
        self.command='exit'

    @commandDecorator
    def exec(self,*args, **kwargs):
        return 0


@dataclass
class showDBsCommand(commandAbstract):
    global currDB
    global DBs

    def __init__(self):
        super(showDBsCommand, self).__init__()
        self.command='shdb'

    @commandDecorator
    def exec(self,*args, **kwargs):
        for db in DBs.keys():
            print(db)
        return 1


class printDBCommand(commandAbstract):
    global currDB
    global DBs

    def __init__(self):
        super(printDBCommand, self).__init__()
        self.command='pdb'

    @commandDecorator
    def exec(self,*args, **kwargs):
        db = DBs[args[0]]
        for (k,v) in zip(db.keys(),db.values()):
            print('{0} ::: {1}'.format(k,v))
        return 1

@dataclass
class currdbCommand(commandAbstract):
    global currDB
    global DBs

    def __init__(self):
        super(currdbCommand, self).__init__()
        self.command='crdb'

    @commandDecorator
    def exec(self,*args, **kwargs):
        print(currDB['name_db'])
        return 1



def Parse(command:str):

    if command=='':
        return 1
    words = command.split(' ')
    if words[0] not in commandsDict.keys():
        print(f'>>> No such command: {words[0]} <<<')
        return 1
    return commandsDict[words[0]].exec(*words[1:])


commandsDict = {'set':setCommand(),
                'get':getCommand(),
                'cdb':createDBCommand(),
                'udb':useDBCommand(),
                'exit':exitCommand(),
                'shdb':showDBsCommand(),
                'crdb':currdbCommand(),
                'pdb':printDBCommand()}

