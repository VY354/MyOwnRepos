import os

from dataclasses import dataclass, asdict, astuple, fields, field
from abc import ABC, abstractmethod

from DBGlobals import *
from DBCommands import *


@dataclass()
class MyDBManagmentSys:
    def start(self):
        while 1:
            line = input('---> ')
            res = Parse(line)
            if res==-1:
                print('>>> Some ERROR occurred !!! <<<')
            if not res:
                break



def main():
    dbms = MyDBManagmentSys()
    dbms.start()




if __name__ == '__main__':
    main()
